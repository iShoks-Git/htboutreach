import { PrismaAdapter } from "@next-auth/prisma-adapter";
import type { NextAuthOptions } from "next-auth";
import { getServerSession } from "next-auth";
import { prisma } from "./prisma";

// LinkedIn "Sign in with LinkedIn using OpenID Connect" product.
// Scopes: openid, profile, email. This is identity only — Sales Navigator data
// remains paste-back via the browser (LinkedIn does not expose Sales Nav over
// public OAuth scopes).
const linkedinProvider = {
  id: "linkedin",
  name: "LinkedIn",
  type: "oauth" as const,
  wellKnown: "https://www.linkedin.com/oauth/.well-known/openid-configuration",
  authorization: { params: { scope: "openid profile email" } },
  idToken: true,
  checks: ["state"] as ("state" | "pkce" | "nonce")[],
  clientId: process.env.LINKEDIN_CLIENT_ID,
  clientSecret: process.env.LINKEDIN_CLIENT_SECRET,
  profile(profile: { sub: string; name?: string; email?: string; picture?: string }) {
    return {
      id: profile.sub,
      name: profile.name ?? null,
      email: profile.email ?? null,
      image: profile.picture ?? null,
    };
  },
};

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma) as never,
  providers: [linkedinProvider as never],
  session: { strategy: "database" },
  callbacks: {
    async session({ session, user }) {
      if (session.user) (session.user as { id?: string }).id = user.id;
      return session;
    },
  },
};

export async function requireUser() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) return null;
  return userId;
}
