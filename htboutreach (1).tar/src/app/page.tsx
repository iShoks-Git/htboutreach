import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { HtbApp } from "@/components/HtbApp";
import { SignIn } from "@/components/SignIn";

export default async function Page() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return <SignIn />;
  return <HtbApp />;
}
